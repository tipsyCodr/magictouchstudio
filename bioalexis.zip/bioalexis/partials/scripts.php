<!-- jquery Min JS -->
<script src="/js/jquery.min.js"></script>
<!-- jquery Migrate JS -->
<script src="/js/jquery-migrate-3.0.0.js"></script>
<!-- jquery Ui JS -->
<script src="/js/jquery-ui.min.js"></script>
<!-- Easing JS -->
<script src="/js/easing.js"></script>
<!-- Color JS -->
<script src="/js/colors.js"></script>
<!-- Popper JS -->
<script src="/js/popper.min.js"></script>
<!-- Bootstrap Datepicker JS -->
<script src="/js/bootstrap-datepicker.js"></script>
<!-- Jquery Nav JS -->
<script src="/js/jquery.nav.js"></script>
<!-- Slicknav JS -->
<script src="/js/slicknav.min.js"></script>
<!-- ScrollUp JS -->
<script src="/js/jquery.scrollUp.min.js"></script>
<!-- Niceselect JS -->
<script src="/js/niceselect.js"></script>
<!-- Tilt Jquery JS -->
<script src="/js/tilt.jquery.min.js"></script>
<!-- Owl Carousel JS -->
<script src="/js/owl-carousel.js"></script>
<!-- counterup JS -->
<script src="/js/jquery.counterup.min.js"></script>
<!-- Steller JS -->
<script src="/js/steller.js"></script>
<!-- Wow JS -->
<script src="/js/wow.min.js"></script>
<!-- Magnific Popup JS -->
<script src="/js/jquery.magnific-popup.min.js"></script>
<!-- Counter Up CDN JS -->
<script src="http://cdnjs.cloudflare.com/ajax/libs/waypoints/2.0.3/waypoints.min.js"></script>
<!-- Bootstrap JS -->
<script src="/js/bootstrap.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/lightbox2/2.11.5//js/lightbox.min.js"
	integrity="sha512-KbRFbjA5bwNan6DvPl1ODUolvTTZ/vckssnFhka5cG80JVa5zSlRPCr055xSgU/q6oMIGhZWLhcbgIC0fyw3RQ=="
	crossorigin="anonymous" referrerpolicy="no-referrer"></script>
<!-- Main JS -->
<script src="/js/main.js"></script>